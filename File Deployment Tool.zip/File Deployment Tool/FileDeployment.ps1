# List of target computers
$computers = get-content "WriteComputerList.txt"

# List of source folders
$sourceFolders = get-content "FolderPath.txt"

# List of destination paths
$destinationPath = get-content "DestinationPathway.txt"

# Log file path
$logFilePath = "deployment.log"

# Create a log file or append to an existing one
$null = New-Item -Path $logFilePath -ItemType File -Force


# Loop through each computer
foreach ($computer in $computers) {
    # Loop through each source folder
	if ($sourceFolders.Count -eq 1) {
        try {
			# Copy the folder
			Copy-Item -Path $sourceFolders -Destination $computer\$destinationPath -Recurse -Container -ErrorAction Stop
			 # Log the successful deployment
            Add-Content $logFilePath -Value "$computer COPIED OK"
        }
        catch {
            # Log the deployment failure
            Add-Content $logFilePath -Value "Error: $computer COPY FAILED"
        }
    }
    else {
        # Multiple folders in the list
        foreach ($sourceFolder in $sourceFolders) {
           # Copy the folder to the remote computer
			try {
				Copy-Item -Path $sourceFolder -Destination $computer\$destinationPath -Recurse -Container -ErrorAction Stop

				# Log the successful deployment
				Add-Content $logFilePath -Value "$computer COPIED OK"
			}
			catch {
				# Log the deployment failure
				Add-Content $logFilePath -Value "Error: $computer COPY FAILED"
			}
		}
	}
}
Start-Process -FilePath $logFilePath